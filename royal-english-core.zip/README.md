# Royal English B1

**The British English Method**

**Author: prof Rodrigo Bastos Ferreira**

[Open the complete interactive course](https://logica3000-pianist.github.io/royal-english-b1/)

Ten units with 40 lesson pages per unit, entirely in English.

- Part A: reading, British listening and exercises.
- Part B: vocabulary, grammar, general and business English practice.
- Part C: writing, tips, models and exercises.

## Included

400 lesson pages, 1,273 activities, 30 British recordings with subtitles, 20 contextual photographs used across 113 lesson image placements, complete answer keys, local progress and writing storage, search and backup export/import.

[Download the complete 635-page book](Royal_English_B1.pdf). The book includes 400 lesson pages plus front matter, listening scripts, credits and the final answer key. Listening links open the matching online lesson.

Audio uses synthetic British English narration. Writing models are suggested responses, rather than automatic assessments. Image and font source credits are included in the course.

## Hosting

Static files served from the root of the main branch with GitHub Pages. No installation or API key is required. Learner work is saved locally in the browser.
